// © Author: itsfizys
// https://discord.gg/aerox

const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require('discord.js');
const { TicketConfig, Ticket } = require('../../../data/models');
const { logTicketEvent, hasSupportRole } = require('../../../lib/ticketUtils');

function reply(ctx, text) {
    const container = new ContainerBuilder().setAccentColor(0x2B2D31)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
    const opts = { components: [container], flags: MessageFlags.IsComponentsV2 };
    return ctx.deferred ? ctx.editReply(opts) : ctx.reply(opts);
}

function replyTitled(ctx, title, body) {
    const container = new ContainerBuilder().setAccentColor(0x2B2D31)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(title))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(body));
    const opts = { components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } };
    return ctx.deferred ? ctx.editReply(opts) : ctx.reply(opts);
}

module.exports = {
    async execute(interactionOrMessage) {
        const guild = interactionOrMessage.guild;
        const channel = interactionOrMessage.channel;
        const userId = interactionOrMessage.user?.id || interactionOrMessage.author?.id;

        const [ticket, config] = await Promise.all([
            Ticket.findOne({ where: { channelId: channel.id } }),
            TicketConfig.findOne({ where: { guildId: guild.id } })
        ]);
        if (!ticket) return reply(interactionOrMessage, 'This channel is not a valid ticket.');
        if (!config) return reply(interactionOrMessage, 'Ticket system is not configured.');

        const member = guild.members.cache.get(userId);
        if (ticket.userId !== userId && !hasSupportRole(member, config)) {
            return reply(interactionOrMessage, 'You don\'t have permission to claim tickets.');
        }

        if (ticket.status === 'deleted') return reply(interactionOrMessage, 'This ticket has been deleted and cannot be claimed.');
        if (ticket.status === 'closed') return reply(interactionOrMessage, 'This ticket is closed. Please reopen it before claiming.');

        if (ticket.claimedBy) {
            return reply(interactionOrMessage, `This ticket has already been claimed by <@${ticket.claimedBy}>.`);
        }

        ticket.claimedBy = userId;
        ticket.status = 'claimed';
        await ticket.save();

        logTicketEvent(guild, config, 'Ticket Claimed', `**Ticket:** ${channel}\n**Claimed by:** <@${userId}>`).catch(() => {});

        return replyTitled(interactionOrMessage, '### Ticket Claimed', `This ticket has been claimed by <@${userId}>.`);
    }
};

/**
 * Project: Melon
 * Author: itsfizys (Aegis)
 * Organization: AeroX Development
 * GitHub: https://github.com/itsfizys
 * License: Custom
 * © 2026 AeroX Development. All rights reserved.
 */