// © Author: itsfizys
// https://discord.gg/aerox

const { DataTypes } = require('sequelize');
const BaseModel = require('../BaseModel');

class GiveawayEntry extends BaseModel {
    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                giveawayId: { type: DataTypes.INTEGER, allowNull: false },
                userId: { type: DataTypes.STRING, allowNull: false }
            },
            {
                sequelize,
                modelName: 'GiveawayEntry',
                tableName: 'giveaway_entries',
                timestamps: true,
                indexes: [
                    { fields: ['giveawayId'] },
                    { fields: ['giveawayId', 'userId'], unique: true },
                ],
            }
        );

        return this;
    }

    static associate(models) {
        this.belongsTo(models.Giveaway, {
            foreignKey: 'giveawayId',
            as: 'giveaway',
        });
    }
}

module.exports = GiveawayEntry;

/*
: ! Aegis !
    + Discord: itsfizys
    + Portfolio: https://itsfiizys.com
    + Community: https://discord.gg/8wfT8SfB5Z  (Melon )
    + for any queries reach out Community or DM me.
*/

/**
 * Project: Melon
 * Author: itsfizys (Aegis)
 * Organization: AeroX Development
 * GitHub: https://github.com/itsfizys
 * License: Custom
 * © 2026 AeroX Development. All rights reserved.
 */